This is just a basic linux device driver which explains about the IOCTL.

Please refer this URL for the complete tutorial of this example source code.
https://embetronicx.com/tutorials/linux/device-drivers/ioctl-tutorial-in-linux/